<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Event Management System</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item ">
                <a class="nav-link" href="RegistrationForm.php">Registration</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="TeamForm.php">Manage Teams</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="EventForm.php">Manage Events</a>
            </li>
        </ul>
    </div>
</nav>